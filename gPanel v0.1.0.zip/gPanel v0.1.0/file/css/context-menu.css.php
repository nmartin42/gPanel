<style>
/*context Menu*/
.ctx {
    position: absolute;
    z-index:10000;
    width: 250px;
    background: white;
    overflow: hidden;
    opacity: 0;
    -webkit-box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.3);
    -moz-box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.3);
    box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.3);
    transform: scale(0);
    transition-duration: 0.1s;
}
.ctx-show {
    transform: scale(1);
    opacity: 1;
}

.ctx > .menu {
    list-style: none;
}
.ctx > .menu > li {
  position: relative;
  font-size: 17px;
  padding: 6px 0;
  padding-left: 48px;
  cursor: pointer;
  margin-left: -40px;
}
.ctx > .menu > li:hover {
  background: rgb(240,240,240);
}
.ctx > .menu > li:before {
  content: '';
  position: absolute;
  left: 12px;
  top: 6px;
  display: block;
  width: 20px;
  height: 20px;
  background-size: contain;
  background-position: center center;
}
.ctx > .menu > .add-picture:before { background-image: url('https://jewl-photography.net/file/img/icon/picture.svg'); }
.ctx > .menu > .add-gallery:before,.ctx > .menu > .create-gallery:before { background-image: url('https://jewl-photography.net/file/img/icon/file.svg'); }
.ctx > .menu > .remove:before { background-image: url('https://jewl-photography.net/file/img/icon/trash.svg'); }
.ctx > .menu > .rename:before { background-image: url('https://jewl-photography.net/file/img/icon/rename.svg'); }
.ctx > .menu > .edit:before { background-image: url('https://jewl-photography.net/file/img/icon/edit.png'); }
.ctx > .menu > .add-to:before,.ctx > .menu > .go-to:before { background-image: url('https://jewl-photography.net/file/img/icon/share.png'); }

</style>