<style>
    .notif-box {
        margin-top: 45px;
        height: 230px;
        overflow: hidden;
    }
    
    .notif {
        padding: 10px;
        position: relative;
        animation: 1.5s notif;
        overflow: hidden;
    }
    .notif:after {
        content: "";
        width: 4px;
        height: 100%;
        position: absolute;
        right: 0;
        top:0;
        animation: 1.5s notif-after;
    }
    .notif:before {
        content: "";
        background: white;
        width: 0;
        height: 100%;
        position: absolute;
        right: 0;
        top:0;
        animation: 1.5s notif-before;
    }
    .notif.remove:after {
        animation: 0.5s notif-remove-after;
    }
    .notif.remove:before {
        animation: 0.5s notif-remove-before;
    }
@keyframes notif-after {
    0%{width:100%;height:4px;right:100%;}
   33%{width:100%;height:4px;right:0%;}
   66%{width:100%;height:100%;right:0%;}
  100%{width:4px; right:0%;}
}
@keyframes notif-before {
    0%{width:100%;height:100%;right:0%;}
   66%{width:100%;right:0%;}
  100%{width:0%;  right:0%;}
}
@keyframes notif-remove-after {
    0%{right:0%;  width:0%;}
   50%{right:0%;  width:100%;}
  100%{right:100%;width:0%;}
}
@keyframes notif-remove-before {
    0%{width:0%;}
   50%{width:100%;}
  100%{width:100%;right:0%;}
}
    .notif.level-0 {
        background: rgb(200,255,200);
    }
    .notif.level-0:after {
        background: green;
    }
    .notif.level-1 {
        background: rgb(255,253,200);
    }
    .notif.level-1:after {
        background: rgb(235,223,0);
    }
    .notif.level-2 {
        background: rgb(255,200,200);
    }
    .notif.level-2:after {
        background: rgb(194,0,16);
    }
</style>