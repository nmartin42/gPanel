<??>
<style>
body {
    margin: 0;
    font-family: myriad-pro;
    overflow-x: hidden;
}

.dark {
    background: #3e4147;
    color: #a7aab0;
}
.dark > .main-area > .left-bar {
    background: #36393f;
}
.dark > .add-menu > .show, .dark > .add-menu > .artist {
    background: #36393f;
}
.dark > .add-menu > .show, .dark > .add-menu > .artist > form > input {
    background: #36393f;
    color: #a7aab0;
    border: 1px solid #a7aab0;
    padding: 10px;
}
.dark > .status-bar > .status-item {
    filter: invert(100%);
}
.dark > .main-area > .left-bar > .mnbtn > .add-btn {
    background: #18191c;
}
.dark > .main-area > .left-bar > .mnbtn > .menu, .dark > .ctx {
    background: #36393f;
}
.dark > .main-area > .left-bar > .mnbtn > .menu > ul > li:hover, .dark > .ctx > .dump > li:hover {
    background: #202225;
}
.dark > .main-area > .left-bar > .active-users {
    border-top: 1px solid #18191c;
    border-bottom: 1px solid #18191c;
}
.dark > .main-area > .left-bar > .mnbtn > .add-btn > .text:before {
    filter: invert(0.8);
}
.dark > .main-area > .left-bar > .active-users:before {
    background: #18191c;
}
.dark > .main-area > .content > .data-view > .dump > .set-day > .set-stage > .set-type > .item-div {
    color: #000;
}
.dark > .main-area > .content > .cat > h1 {
    color: #e3e9f2;
}
.dark > .main-area > .content > .cat > h1::after {
    color: #e3e9f2;
    filter: invert(88%);
}

/*Page*/
.main-area {
    -webkit-user-select: none;  
    -moz-user-select: none;    
    -ms-user-select: none;      
    user-select: none;
}
.left-bar {
  position: fixed;
  left:0;
  top: 0;
  padding-top: 100px;
  width: 250px;
  height: 100%;
  -webkit-box-shadow: -25px 0px 50px 0px rgba(0,0,0,0.3);
  -moz-box-shadow: -25px 0px 50px 0px rgba(0,0,0,0.3);
  box-shadow: -25px 0px 50px 0px rgba(0,0,0,0.3);
}
.left-bar > .dark-mode {
    text-decoration: underline;
    cursor: pointer;
    position: fixed;
    top: 10px;
    left: 10px;
}
.left-bar > .active-users {
    position: relative;
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    margin-top: 75px;
    height: 40px;
    padding: 15px 10px;
}
.active-users > .dump {
    overflow: hidden;
}
.left-bar > .active-users:before {
    content: 'Currently Active';
    position: absolute;
    top:-12px;
    background: white;
    padding: 0 10px;
    z-index: 0;
}
.active-user {
    position: absolute;
    background-position: center;
    background-size: contain;
    width: 40px;
    height: 40px;
    border-radius: 50px;
    cursor: pointer;
}
.active-user:nth-child(2) {left:30px;}
.active-user:nth-child(3) {left:60px;}
.active-user:nth-child(4) {left:90px;}
.active-user:nth-child(5) {left:120px;}
.active-user:nth-child(6) {left:140px;}
.active-user:nth-child(7) {left:160px;}

.loading-background {
    position: fixed;
    left: 0;
    top: -100%;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
}
.loading-background.show {
    animation: loading-background 1s;
    top: 0;
}
@keyframes loading-background {
    0% { transform: rotateX(90deg); top: -50%; }
  100% { transform: rotateX(0deg); top: 0%; }
}

.loading-background > .label{
    margin: 60px auto;
    font-size: 50px;
    width: 190px;
    color: white;
}

.loading-container {
    position: relative;
    width: 100px;
    height:100px;
}
.loading-container > .loader1{
    position: absolute;
    background: white;
    border: 25px solid rgb(230,230,230);
    border-top: 25px solid rgb(150,150,150);
    border-radius: 100px;
    width: 100%;
    height: 100%;
    animation: loading1 1s infinite;
}
.loading-container > .loader2{
    position: absolute;
    margin: 24%;
    background: white;
    border: 26px solid rgb(230,230,230);
    border-top: 26px solid rgb(150,150,150);
    border-radius: 100px;
    width: 50%;
    height: 50%;
    animation: loading2 1s infinite;
}
@keyframes loading1 {
    0% { transform: rotateZ(0deg) rotateY(0deg); }
   50% { transform: rotateZ(180deg) rotateY(90deg); }
  100% { transform: rotateZ(360deg) rotateY(0deg); }
}
@keyframes loading2 {
    0% { transform: rotateZ(180deg) rotateY(0deg); }
   50% { transform: rotateZ(0deg) rotateY(-90deg); }
  100% { transform: rotateZ(-180deg) rotateY(0deg); }
}

.cat {
    position: relative;
    overflow: hidden;
    transition-duration: 1s;
}

.cat.show > .load-more {
    bottom: 0px;
}
.load-more {
    position: absolute;
    bottom: -100px;
    left: -1px;
    width: 100px;
    background: rgb(41, 41, 41);
    color: white;
    padding: 10px;
    padding-left: 30px;
    padding-right: 20px;
    border-radius: 0 50px 50px 0;
    margin-bottom: 5px;
    cursor: pointer;
    transition-duration: .3s;
    z-index: 0;
    border: 1px solid black;
}
.load-more:before {
    content: 'Load More...';
    text
}
.load-more:after {
    content: '';
    position: absolute;
    right: 200px;
    top:0;
    border-radius: 50px;
    background: white;
    width:38px;
    height:38px;
    transition-duration: .3s;
    z-index: -1;
}
.load-more:hover {
    background:white;
    color: black;
    padding-right: 50px;
}
.load-more:hover:after {
    background:black;
    right: 0px;
}
.load-more.click {
    animation: load-more-click 5s;
}
.load-more.click:after {
    animation: load-more-click-after 5s;
}
.load-more.click:before {
    content: 'Load More...';
    animation: load-more-click-before 5s;
}

@keyframes load-more-click {
    0% { width: 150px;background: white;color:black; }
   20% { width: 120%; }
   40% { bottom: 0px; }
   60% { bottom: -100px;width: 120%;background: white;color:black; }
   80% { bottom: -100px;width: 100px;background: rgb(41, 41, 41); }
  100% { bottom: 0px; }
}
@keyframes load-more-click-after {
   00% { right:0;background:black; }
   70% { right:0;background:black; }
   90% { right: 200px;background:white; }
}
@keyframes load-more-click-before {
    0% { content: 'Loading More...'; }
   80% { content: 'Loading More...'; }
   81% { content: 'Load More...'; }
}

.content {
    margin-left: 275px;
    margin-right: -250px;
}
.set-day > h1 {
    width: 100px;
}
.content > .cat > h1 {
  position: relative;
  color: rgb(50,50,50);
  font-size: 18px;
  padding: 20px;
  padding-bottom: 10px;
  cursor: pointer;
  -webkit-box-shadow: 0px 5px 0px 0px rgba(0,0,0,0);
  -moz-box-shadow: 0px 5px 0px 0px rgba(0,0,0,0);
  box-shadow: 0px 5px 0px 0px rgba(0,0,0,0);
  transition-duration: .5s;
}
.content > .cat.show > h1 {
  -webkit-box-shadow: 0px 5px 7px 0px rgba(0,0,0,0.1);
  -moz-box-shadow: 0px 5px 7px 0px rgba(0,0,0,0.1);
  box-shadow: 0px 5px 5px 0px rgba(0,0,0,0.1);
}
.content > .cat:not('.show') > h1:before {
  content: '';
  display: block;
  position: relative;
  left: -25px;
  top: 35px;
  width: 100%;
  height: 1px;
  background: rgb(200,200,200);
}
.content > .cat > h1:after {
  content: '';
  position: relative;
  top: -16px;
  margin-left: 10px;
  margin-bottom: -20px;
  background-image: url('https://jewl-photography.net/file/img/icon/arrow.png');
  display: inline-block;
  width: 20px;
  height: 20px;
  background-position: center center;
  background-size: contain;
  transition-duration: .3s;
}
.content > .show > h1:after {
  transform: rotate(90deg);
}

.item-div {
    position: relative;
    cursor: pointer;
    transition-duration: .2s;
    overflow: hidden;
}

.type_list > .dump > .item-div {
    padding: 10px;
    padding-left: 25px;
    border: 1px solid rgb(230,230,230);
    background: white;
    border-radius: 2px;
    margin: 5px;
}
.type_list > .dump > .selected {
    border: 1px solid rgb(200,200,255);
    background: rgb(250,250,255);
    border-radius: 10px;
}

.type_image-small > .dump > .item-div {
    position: relative;
    padding: 10px;
    background-position: center;
    background-size: cover;
    border: 1px solid rgb(230,230,230);
    background-color: white;
    width: 100px;
    height: 100px;
    border-radius: 5px;
    margin: 5px;
    float: left;
}
.type_image-small > .dump > .item-div > span {
    position: absolute;
    bottom:0;
    left:0;
    background: white;
    display: block;
    height: 20px;
    padding:10px;
    overflow: hidden;
    width: 100%;
    transition-duration: .5s;
}
.type_image-small > .dump > .selected {
    border: 1px solid rgb(200,200,255);
    border-radius: 15px;
    opacity: .5;
}
.type_image-small > .dump > .selected > span {
    background: rgb(235,235,255);
}

.type_image-large > .dump > .item-div {
    position: relative;
    padding: 10px;
    background-position: center;
    background-size: cover;
    border: 1px solid rgb(230,230,230);
    background-color: white;
    width: 300px;
    height: 200px;
    border-radius: 5px;
    margin: 5px;
    float: left;
}
.type_image-large > .dump > .item-div > span {
    position: absolute;
    bottom:0;
    left:0;
    background: white;
    display: block;
    height: 20px;
    width: 100%;
    padding:15px;
    overflow: hidden;
    transition-duration: .5s;
}
.type_image-large > .dump > .selected {
    border: 1px solid rgb(200,200,255);
    border-radius: 15px;
    opacity: .5;
}
.type_image-large > .dump > .selected > span {
    background: rgb(235,235,255);
}

.item-div > .assign-div {
    position: absolute;
    left: 0;
    top: 0;
    font-size: 14px;
    background:rgba(186, 255, 194, 0.9);
    width: 0%;
    height: 100%;
    padding: 2px 0px;
    padding-left: 25px;
    z-index: 1;
    overflow: hidden;
    transition-duration: .5s;
}
.item-div > .assign-div.toggle-show {
    cursor: pointer;
}
.item-div > .assign-div.show {
    width: 100%;
    padding: 2px 25px;
}
.assign-div > .assign {
    border: 2px solid black;
    border-radius: 20px;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: 80%;
    position: absolute;
    cursor: pointer;
    right: 0;
    top: -50px;
    width: 30px;
    height: 30px;
    opacity: 0;
    transition-duration: .1s;
}
.assign-div.show > .assign {
    top: 3px;
    opacity: 0.3;
}
.assign-div.toggle-show > .assign {
    display: none;
}
.assign-div > .assign:hover {
    opacity: 1;
}
.assign-div > .add-stream {
  background-image: url('https://jewl-photography.net/file/img/icon/wifi.svg');
    right: 110px;
}
.assign-div >  .add-vis {
  background-image: url('https://jewl-photography.net/file/img/icon/magic.svg');
    right: 60px;
}
.item-div > div {
    display: inline-block;
}
.item-div > a {
    width: 40px;
}
.item-div > a > .img {
    background-size: cover;
    background-position: center;
    width: 40px;
    height: 40px;
}
.item-div > .time {
    margin-left: 20px;
}
.item-div > .name {
    position: absolute;
    top: 5px;
    margin-left: 50px;
    font-size: 40px;
}

/*Status Bar*/
.status-bar {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 250px;
    height: 40px;
    padding: 10px;
}
.status-bar > .status-item {
    background-position: center;
    background-size: contain;
    display: inline-block;
    cursor: pointer;
    margin: 2px 0;
    width: 37px;
    height: 37px;
    opacity: 0.3;
    transition-duration: .1s;
}
.status-bar > .status-item.disable {
    opacity: 0.1;
    cursor: not-allowed;
}
.status-bar > .status-item.active {
    opacity: 1;
}
</style>