<style>
.add-btn {
  display: block;
  width: 120px;
  height: 50px;
  text-align: center;
  border-radius: 50px;
  background: white;
  -webkit-box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.3);
  -moz-box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.3);
  box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.3);
  cursor: pointer;
  transition-duration: .5s;
}
.add-btn:hover {
  background: rgb(230,230,230);
}
.add-btn > .text {
  position: relative;
  top: 14px;
  left: 10px;
  font-size: 18px;
  padding-left: 15px;
}
.add-btn > .text::before {
  content: '';
  display: block;
  width: 35px;
  height: 35px;
  background-image: url('https://jewl-photography.net/file/img/icon/plus.svg');
  background-position: center center;
  background-size: contain;
  position: absolute;
  top: -7px;
  left: -35px;
  transition-duration: .2s;
}

/*Button Menus*/
.mnbtn {
  position: relative;
}
.mnbtn > .menu {
  background: white;
  width: 110%;
  overflow: hidden;
  position: absolute;
  top: -100%;
  left: 0;
  display: block;
  padding: 6px 0;
  border-radius: 5px;
  -webkit-box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.3);
  -moz-box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.3);
  box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.3);
  transition-duration: 0.2s;
  opacity: 0;
  transform: scaleY(0);
}
.mnbtn > .menu.show {
  top: 0%;
  transform: scaleY(1);
  opacity: 1;
}
.mnbtn > .menu > ul {
  list-style: none;
  margin-left: -40px;
}
.mnbtn > .menu > ul > li {
  position: relative;
  font-size: 17px;
  padding: 6px 0;
  padding-left: 47px;
  cursor: pointer;
}
form.picture-upload > input {
  position: absolute;
  top: -5px;
  left: -5px;
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.mnbtn > .menu > ul > li:hover {
  background: rgb(240,240,240);
}
.mnbtn > .menu > ul > li:marker {
  display: none;
}
.add-menu {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.95);
  transform: scale(0);
  transition-duration: 1s;
  z-index: 100;
}
.add-menu > .x {
  display: block;
}
.add-menu > .x:before {
  content: '';
  position: fixed;
  top: 25px;
  left: 25px;
  background-image: url("https://jewl-photography.net/file/img/icon/x.png");
  background-position: center;
  background-size: cover;
  width: 30px;
  height: 30px;
  filter: invert(1);
  cursor: pointer;
}
.add-menu.show {
  transform: scale(1);
}
.add-menu > div {
  background: white;
  width: 39%;
  margin: 0 auto;
  padding: 10px 50px;
  display: none;
}
.add-menu > .show {
    display: block;
}
</style>