<?php
require(ROOT.'config/context-menu.php');

?>
        <div class='left-bar'>
            <span class='dark-mode'>Dark Mode</span>
            <div class='mnbtn' style='margin-left: 10px;'>
                <span class='add-btn button'>
                    <span class='text'>Add</span>
                </span>
                <span class='menu'>
                    <ul></ul>
                </span>
            </div>
            <div class='notif-box'>
                <div class='dump'></div>
            </div>
            <?/*
            <div class='active-users'>
                <div class='dump'><!--
                    <img class='user active-user' id='' title='' style='background-image: url("https://anoknt.imgix.net/upload/11111195_Turtle Bay-0.png?w=42");'>
                    <img class='user active-user' id='' title='' style='background-image: url("https://anoknt.imgix.net/upload/87777277_isuna-0.jpg?w=42");'>
                    <img class='user active-user' id='' title='' style='background-image: url("https://anoknt.imgix.net/upload/18381099_GAmmatoid-0.png?w=42");'>-->
                </div>
            </div>*/?>
        </div>