<?php // Called from: index/file/elements/content.php
function cpg_query($category) {
    require(ROOT."file/php/category.php/query.php");
}
function cpg_category($category) {
    require(ROOT."file/php/category.php/category.php");
}
?>