<?php
require(__DIR__.'/../php/call.php');

$category_id = $_POST['n'];
/* ------ NOTICE: Code block no longer necessary? Please revisit.... -------
if(count($context_menu[$category_id]['content']) == count($context_menu[$category_id]['trigger'])) {} else {
    echo "ERROR: context_menu.content and context_menu.trigger must be equal length.";
    exit;
}*/

class context_menu {
    public $category_id;
    public $content;
    
    function create($create_category_id,$create_content) {
        $this->category_id = $create_category_id;
        $this->content = $create_content;
    }
}

$m = require(ROOT.'config/context-menu.php');
$context_menu = array();
$i = 0;
while($i < count($m)) {
    $context_menu[$i] = new context_menu();
    $context_menu[$i]->create($m[$i]['category_id'],$m[$i]['content']);
    $i++;
}

unset($m);
$ctx = $context_menu[array_search($category_id, array_column($context_menu, 'category_id'))];

//#####################################################
$t = false;
if($ctx->category_id == $category_id) {
    $t = true;
}

if($t == false) {
    echo "There's no context menu for this Category";
    exit;
}

require(__DIR__.'/context-menu-content.php');

echo $return;
