<?
if(isset($_GET['ajax'])) {
?>
    <div class='loading-container' style='transform: scale(<? echo $_GET['size']; ?>);<? echo $_GET['style']; ?>'>
        <div class='loader1'></div>
        <div class='loader2'></div>
    </div>
<?
} else {

    function loader($style) {
        if(!is_array($style)) {
            $style = [$style,''];
        }
?>
    <div class='loading-container' style='transform: scale(<? echo $style[0]; ?>);<? echo $style[1]; ?>'>
        <div class='loader1'></div>
        <div class='loader2'></div>
    </div>
<?
    }
}