<?php
class category {
    public $id;
    public $name;
    public $type;
    public $query;
    public $table;
    public $extra;
    
    function create($create) {
        $this->id = $create['id'];
        $this->name = $create['name'];
        $this->type = $create['type'];
        $this->query = $create['query'];
        $this->table = $create['table'];
        if(isset($create['extra'])) {
            $this->extra = $create['extra'];
        }
    }
}

$m = require(ROOT.'config/layout.php');
$category = array();
$i=0;
while($i < count($m)) {
    $category[$i] = new category();
    $category[$i]->create($m[$i]);
    $i++;
}

if(!isset($_GET['ajax'])) {
    require(ROOT.'file/php/decode_markdown.php');
    require(ROOT.'file/elements/category.php');
    
    $i = 0;
    while($i < count($category)) {
        cpg_category($category[$i]);
        $i++;
    }
}
unset($m);