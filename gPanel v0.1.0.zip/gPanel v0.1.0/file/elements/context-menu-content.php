<?
$return = '';
$i=1;
while($i <= count($ctx->content)) {
    if(isset($ctx->content["$i"]['extra'])) {
        switch($ctx->content["$i"]['trigger']) {
            case "gpanel.upload":
                if(empty($ctx->content["$i"]['extra']['upload']['save_location'])) { echo "Error: extra.upload.location was not provided."; break; }
                $save_location = parse_url( $ctx->content["$i"]['extra']['upload']['save_location'], PHP_URL_PATH );
                if(file_exists($save_location)) {}
                if(empty($ctx->content["$i"]['extra']['upload']['amount'])) { echo "Error: extra.upload.amount was not provided. Expected \"single\" or \"multiple\""; break; } else {
                if($ctx->content["$i"]['extra']['upload']['amount'] == 'multiple') { $multi = "multiple='multiple'";} else {$multi = '';} }
                if(empty($ctx->content["$i"]['extra']['upload']['max_size'])) { echo "Error: extra.upload.max_size was not provided."; break; }
                if(empty($ctx->content["$i"]['extra']['upload']['query'])) { echo "Error: extra.upload.query was not provided. Expected SQL INSERT query."; break; }
                $return = $return."     <li class='ctx-option ctx-upload-label no-event'>".$ctx->content["$i"]['label']."
                                        <form action='file/php/context_function.php' method='POST' enctype='multipart/form-data' class='context-upload-form'>
                                            <input type='hidden' name='n[]' value='".$ctx->content["$i"]['trigger']."'>
                                            <input type='hidden' name='n[]' value='".$save_location."'>
                                            <input type='hidden' name='n[]' value='".$ctx->content["$i"]['extra']['upload']['max_size']."'>
                                            <input type='hidden' name='n[]' value='".implode(",",$ctx->content["$i"]['extra']['upload']['type'])."'>
                                            <textarea style='display:none;' name='n[]' >".$ctx->content["$i"]['extra']['upload']['query']."'</textarea>
                                            <input type='file' class='context-upload-button' name='uploaded_files[]' $multi class='ctx-upload-button'>
                                        </form></li>";
            break;
            case "gpanel.delete_file":
                $return = $return."<li class='ctx-option ctx-upload-label' option-method='".$ctx->content["$i"]['trigger']."'>".$ctx->content["$i"]['label']."
                <input type='hidden' class='context-return' name='file_location' value='".$ctx->content["$i"]['extra']['delete_file']['file_location']."'>
                <input type='hidden' class='context-return' name='database_table' value='".$ctx->content["$i"]['extra']['delete_file']['database_table']."'>
                <input type='hidden' class='context-return' name='file_value' value='".$ctx->content["$i"]['extra']['delete_file']['file_value']."'></li>";
            break;
        }
    } else {
       $return = $return."    <li class='ctx-option' option-method='".$ctx->content["$i"]['trigger']."'>".$ctx->content["$i"]['label']."</li>\n";
    }
$i++;
}