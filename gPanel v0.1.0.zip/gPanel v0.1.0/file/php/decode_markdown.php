<?php
/*
$i[-1] = 0;
while($i < count($layout)) {
    $i[$i] = str_replace("/\[[A-z0-9]*\]/","",$layout[0][3]);
    $i[-1]++;
}
*/