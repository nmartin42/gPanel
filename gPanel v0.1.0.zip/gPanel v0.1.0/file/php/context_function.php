<?
require('call.php');
header('Access-Control-Allow-Origin: *');
if(isset($_GET['t'])) {header('Content-Type: application/json');}
$i = 0;
$trigger = $_POST['n'][0];
array_shift($_POST['n']);
$n = $_POST['n'];

switch ($trigger) {
    case "gpanel.delete":
        
        while($i < count($n)) {
            sql('DELETE FROM '.$n[$i][1].' WHERE id="'.$n[$i][0].'";');
            $i++;
        }
        echo "gpanel.delete";
    break;
    case "gpanel.upload":
        $return_value = '';
            while($i < count($_FILES["uploaded_files"]['name'])) {
                $valid_upload = true;
                $fail_why = '';
                $fail_level = '1';
                
                $random_string = rand(0,99999999);
                $file_extension = strtolower(pathinfo($_FILES["uploaded_files"]["name"][$i],PATHINFO_EXTENSION)); //Img Extension
                $new_file_name = "$random_string"."_".$_FILES["uploaded_files"]["name"][$i]; //File name
                $save_location = $n[0]; //Relative Link (No extension)
                $final_save_location = $save_location."".$new_file_name; //Final Link
                // Check file size
                if(!file_exists($save_location)) {
                    $valid_upload = false;
                }
                if(empty($n[1])) { $n[-1] = "16"; } else { $n[-1] = $n[1]; }
                if ($_FILES["uploaded_files"]["size"][$i] > $n[-1]*1000000) {
                    $fail_why = "Your file is too large (Max ".$n[-1]."1000000), you were ". ($_FILES["uploaded_files"]["size"][$i]) .' '.$i;
                    $valid_upload = false;
                }
                // Allow certain file formats
                if(!in_array($file_extension,explode(",",$n[2]))) {
                    $fail_why = "The only allowed file types are: $n[2]";
                    $valid_upload = false;
                }
                if(!file_exists($save_location)) {
                    $fail_why = "extra.upload.save_location does not exist!";
                    $valid_upload = false;
                }
                if($valid_upload == true) {
                    if(move_uploaded_file($_FILES["uploaded_files"]["tmp_name"][$i], $final_save_location)) {
                        $return_value = $return_value.' '.$_FILES["uploaded_files"]["name"][$i];
                        sql(preg_replace("/\'$/","",str_replace('???FINALIMAGE???',$new_file_name,$n[3])));
                    } else {
                        header('Location: '.DOM."?notif=".$_FILES["uploaded_files"]['error'][$i]."&lev=2");
                    }
                } else {
                    header('Location: '.DOM."?notif=$fail_why&lev=$fail_level");
                }
                $i++;
            }
        header('Location: '.DOM."?notif=$return_value were uploaded!&lev=0");
    break;
    case "gpanel.delete_file":
    
        while($i < count($n[0])) {
            $image_name = sql_a(sql('SELECT '.$n[1]["file_value"].' FROM '.$n[1]["database_table"].' WHERE id = '.$n[0][$i].';'));
            sql("DELETE FROM ".$n[1]["database_table"]." WHERE id = '".$n[0][$i]."';");
            unlink($n[1]["file_location"] . $image_name[$n[1]["file_value"]]);
            $i++;
        }
        echo "gpanel.delete_file";
    break;
    case "gpanel.load_more":
        require('../elements/content.php');
        $r = array();
        $q = sql("SELECT id,url FROM img_all ORDER BY id DESC LIMIT $n[0],20;");
        while($i<n_sql($q)) {
            $r[$i] = sql_a($q);
            $i++;
        }
        echo json_encode($r);
    break;
    default:
        require(ROOT."config/functions.php");
} 