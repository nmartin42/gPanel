<?php
require(ROOT."config/general.php");
$dbc = mysqli_connect($database["hostname"],$database["user"],$database["password"],$database["database"]) OR die("Connection failed: " . mysqli_connect_error());
mysqli_set_charset($dbc,'utf8');