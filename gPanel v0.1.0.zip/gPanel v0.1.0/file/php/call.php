<?php
require(__DIR__.'/../../config/general.php');
//require(ROOT.'/encode.php');
define("ROOT",preg_replace("/\/$/","",$server_root)."/");
define("DOM",$current_domain);
require(ROOT."file/elements/loader.php");
require(ROOT."file/php/sql_function.php");