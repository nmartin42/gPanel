<?php

function call_sql() {
    require(ROOT.'file/php/sql_connect.php');
    return $dbc;
}
function sql($query) {
    $r = mysqli_query(call_sql(),$query);
    return $r;
}
function a_sql($query) {
    $r = mysqli_fetch_assoc(mysqli_query(call_sql(),$query));
    return $r;
}
function sql_a($query) {
    $r = mysqli_fetch_assoc($query);
    return $r;
}
function n_sql($query) {
    $r = mysqli_fetch_row(mysqli_query(call_sql(),$query));
    return $r;
}
function sql_n($query) {
    $r = mysqli_fetch_row($query);
    return $r;
}
function sql_num($query) {
    return mysqli_num_rows($query);
}