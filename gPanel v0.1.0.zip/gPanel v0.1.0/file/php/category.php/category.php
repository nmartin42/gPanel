<?php
// Check to see if the table called in the SQL query matches the table provided in category.table
if($category->table != preg_replace("/.*FROM ([A-z]*).*/","$1",$category->query)) {
        ?>
        <div class='cat data-view' style='height: 68px;'>
            <h1>ERROR: category.query("FROM [table]") must be equal to category.table!
                Provided: category.table = "<? echo $category->table; ?>", should be: category.table = "<? echo preg_replace("/.*FROM ([A-z]*).*/","$1",$category->query); ?>"</h1>
        </div><?
    exit;
}
//Print a category coresponding to the correct category.type
switch ($category->type) {
    case "list":
        ?>
        <div class='cat data-view ctx-click type_list' id='<? echo $category->id; ?>' category-table="<? echo $category->table; ?>" category-type='list' style='height: 68px;'>
            <h1><? echo $category->name; ?></h1>
            <div class='dump'>
                <? cpg_query($category); ?>
            </div>
            <label class='load-more'></label>
        </div>
        <?
    break;
    case "image-small":
        if(empty($category->extra['image_url']['url_value'])) { echo "ERROR: Missing extra.image_url.url_value"; exit; }
        ?>
        <div class='cat data-view ctx-click type_image-small' id='<? echo $category->id; ?>' category-table="<? echo $category->table; ?>" category-type='image-small' style='height: 68px;'>
            <h1><? echo $category->name; ?></h1>
            <div class='dump'>
                <? cpg_query($category); ?>
            </div>
            <label class='load-more'></label>
        </div>
        <?
    break;
    case "image-large":
        if(empty($category->extra['image_url']['url_value'])) { echo "ERROR: Missing extra.image_url.url_value"; exit; }
        ?>
        <div class='cat data-view ctx-click type_image-large' id='<? echo $category->id; ?>' category-table="<? echo $category->table; ?>" category-type='image-large' style='height: 68px;'>
            <h1><? echo $category->name; ?></h1>
            <div class='dump'>
                <? cpg_query($category); ?>
            </div>
            <label class='load-more'></label>
        </div>
        <?
    break;
    default:
        ?>
        <div class='cat data-view' style='height: 68px;'>
            <h1>ERROR: "<? echo $category->type; ?>" is not a valid category type.</h1>
        </div>
        <?
}