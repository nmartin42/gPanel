<?php

if(isset($_GET['ajax'])) {
    require('call.php');
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    $i = 0;
    $trigger = $_POST['n'][0];
    array_shift($_POST['n']);
    $n = $_POST['n'];
}
$return = '';
$insert = '';

// Check if category.query matches specifecations before executing it
// Check is category.query is a SELECT query
if(strtolower(preg_replace("/([A-z]*).*/","$1",$category->query)) != "select") {
    $return = $return."<div class='click-div item-div'>
            <div>ERROR: category.query only accepts SQL SELECT queries! Provided: ". preg_replace("/([A-z]*).*/","$1",$category->query) ."</div>
        </div>";
    echo $return;
    exit;
}

// Check if category.query includes the "id" row and check if it is the first attribute.
$q = sql($category->query);
$ra = sql_a($q);
if(empty($ra['id'])) {
    $return = $return."<div class='item-div'>
            <div>ERROR: category.query must include a PRIMARY_KEY \"id\" as the first return of your SQL query!<br>
                    Query fields provided: \"".preg_replace("/SELECT ([A-z\,]*).*/","$1",$category->query)."\" Should be: \"id,".preg_replace("/SELECT ([A-z\,]*).*/","$1",$category->query)."\"</div>
        </div>";
    echo $return;
    exit;
}

// Reset query to run through the printing system
$q = sql($category->query);
$qa = sql($category->query);
switch($category->type) {
    case "list":
    $i=0;
    while($i < sql_num($q)) {
        $r = sql_n($q);
        $ra = sql_a($qa);
        $insert = '';
        $ii=0;
        while($ii < count($r)) {
            $insert = $insert."<div class='".$r[$ii]."'>".$r[$ii]."</div>";
            $ii++;
        }
        $return = $return."<div class='click-div item-div selecteable' id='".$ra['id']."'>$insert</div>";
        $i++;
    }
    break;
    case "image-small":
        if(empty($category->extra['text_field']['display'])) {
            $return = $return."ERROR type.image_small requires extra.text_field.display [True/False]";
            echo $return;
            exit;
        } else {
            if(strtolower($category->extra['text_field']['display']) == 'true') {
                if(empty($category->extra['text_field']['text_value'])) {
                    $return = $return."ERROR: extra.text_field.display->true requires extra.text_field.text_value to be set.";
                    echo $return;
                    exit;
                }
                $text_field = true;
            }
        }
    $i=0;
    while($i < sql_num($q)) {
        $r = sql_n($q);
        $ra = sql_a($qa);
        $image_url = $ra[$category->extra['image_url']['url_value']];
        if(isset($category->extra['image_url']['prefix'])) {
            $image_url = $category->extra['image_url']['prefix'] . $image_url;
        }
        if(isset($category->extra['image_url']['prefix'])) {
            $image_url = $image_url . $category->extra['image_url']['suffix'];
        }
        $insert = '';
        if(strtolower($category->extra['text_field']['display']) == 'true') { $insert = "<span>".$ra[$category->extra['text_field']['text_value']]."</span>";}
            $return = $return."<div class='click-div item-div selecteable' id='".$ra['id']."' style='background-image: url(\"".$image_url."\");'>$insert</div>";
        $i++;
    }
    break;
    case "image-large":
        if(empty($category->extra['text_field']['display'])) {
            echo 'ERROR type.image_small requires extra.text_field.display [True/False]';
            exit;
        } else {
            if(strtolower($category->extra['text_field']['display']) == 'true') {
                if(empty($category->extra['text_field']['text_value'])) {
                    echo 'ERROR: extra.text_field.display->true requires extra.text_field.text_value to be set.';
                    exit;
                }
                $text_field = true;
            }
        }
    $i=0;
    while($i < sql_num($q)) {
        $r = sql_n($q);
        $ra = sql_a($qa);
        $image_url = $ra[$category->extra['image_url']['url_value']];
        if(isset($category->extra['image_url']['prefix'])) {
            $image_url = $category->extra['image_url']['prefix'] . $image_url;
        }
        if(isset($category->extra['image_url']['prefix'])) {
            $image_url = $image_url . $category->extra['image_url']['suffix'];
        }
        $insert = '';
        if(strtolower($category->extra['text_field']['display']) == 'true') { $insert = "<span>".$ra[$category->extra['text_field']['text_value']]."</span>";}
            $return = $return."<div class='click-div item-div selecteable' id='".$ra['id']."' style='background-image: url(\"".$image_url."\");'>$insert</div>";
        $i++;
    }
    break;
}
    echo $return;