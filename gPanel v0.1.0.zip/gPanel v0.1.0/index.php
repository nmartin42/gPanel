<?
require("file/php/call.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <script type="text/javascript" src="https://noknt.net/file/js/- jQuery -.js"></script>
        <script type="text/javascript" src="https://andromeda.noknt.net/file/js/- Ajax -.js"></script>
        <link rel='stylesheet' type='text/css'      href='https://jewl-photography.net/file/css/page_home.css'/>
        <? require(ROOT.'file/css/dashboard.css.php'); ?>
        <? require(ROOT.'file/css/add-button.css.php'); ?>
        <? require(ROOT.'file/css/context-menu.css.php'); ?>
        <? require(ROOT.'file/css/left-bar.css.php'); ?>
    </head>
    <body class='<? echo $dark; ?>'>
    <div class='main-area'>
        <? require(ROOT.'file/elements/left-bar.php'); ?>
        <div class='content'>
            <? require(ROOT.'file/elements/content.php'); ?>
        </div>
    </div>
<nav class='ctx' id='context-menu' select-cat=''>
    <ul class='dump menu'></ul>
</nav>
<div class='add-menu'></div>

<nav class='status-bar'>
    <div class='status-item s'     style='background-image: url("https://jewl-photography.net/file/img/icon/s.png");'></div>
    <div class='status-item deselect hover disable'    style='background-image: url("https://jewl-photography.net/file/img/icon/select.png");'></div>
    <div class='status-item multiple disable'  style='background-image: url("https://jewl-photography.net/file/img/icon/multiple.png");' title=''></div>
    <div class='status-item rearange' style='background-image: url("https://jewl-photography.net/file/img/icon/rearrange.png");'></div>
</nav>
<div class='loading-background'>
    <div class='label'>Uploading...</div>
    <? loader([1,'margin:0 auto;']); ?>
</div>
<script>
    $(function(){
        window.history.pushState("","",'/control-panelg/');
        function generate_context_menu_content(category_id) {
            $('.ctx>.dump').load('<?echo DOM;?>/file/elements/loader.php?ajax=true&size=.3&style=margin:%200%20auto;margin-top:-15px;left:-10px;', () => {
                a(category_id,'file/elements/context-menu.php',function(r){
                    $('.ctx>.dump').html(r);
                });
            });
        }
        function generate_context_menu(category_id) {
        }
        function notif(msg,level) {
            $(".notif-box>.dump").append("<div class='n-"+nt+" notif level-"+level+"'>"+msg+"</div>");
            var not = $('.notif-box>.dump>.n-'+nt);
            nt++;
            setTimeout(function(){
                not.addClass('remove');
            },8500);
            setTimeout(function(){
                not.remove();
            },9000);
        }
        function context_function(t,category_id) {
            a(t,'file/php/context_function.php',function(r){
                switch(r) {
                    case "gpanel.delete_file":
                        if($(".ctx").attr('select-type') == 'single') {
                            $(".cat#"+category_id+">.dump>.item-div#"+items[0]).remove();
                            notif("Item deleted!",0);
                        } else {
                            $('.selected').remove();
                            notif("Items deleted!",0);
                        }
                    break;
                }
                console.log(r);
            });
        }
        
        function resize(category_id,category_type) {
            if($('.cat#'+category_id).hasClass('show')) {
                var item_width = $($('.cat#'+category_id+'>.dump>.item-div')[0]).width() + 32;
                var item_height = $($('.cat#'+category_id+'>.dump>.item-div')[0]).height() + 32;
                var content_width = $('.main-area>.content').width();
                var item_per_row = Math.floor(content_width / item_width);
                var item_count = $('.cat#'+category_id+'>.dump>.item-div').length;
                console.log(item_width);
                $('.cat#'+category_id).height((((Math.ceil(item_count / item_per_row) * item_height) + 70) + 68) +"px");
            } else {
                $('.cat#'+category_id).height('68px');
            }
        }
        
        <?
        if(isset($_GET['notif']) && isset($_GET['lev'])) {
            ?>notif("<? echo $_GET['notif']; ?>",<? echo $_GET['lev']; ?>);<?
        }
        ?>
        
        $('.ctx').on('change','.context-upload-button',function(){
            $('.loading-background').addClass('show');
            $(this).parents('.context-upload-form').submit();
        });
        
        
        /*"use strict";*/
        var i = 0;
        var items = [];
        var selection;
        /*LOAD/UNLOAD*/
        /*Dark Mode*/
        $('.dark-mode').click(function(){
            $("body").toggleClass('dark');
            var l = new Object();
            a(l,'https://andromeda.noknt.net/Admin/- Function -.php?l=dark&f=set',function(r){});
        });
        /*Status Bar*/
        $('.status-item.s').click(function(){
              $('.selected').removeClass('selected');
              $('.status-item.s').removeClass('active');
              $('.status-item.s').attr('title','');
        })
        setInterval(function(){
            if($('.selected')[0]) {
                $('.status-item.s').addClass('active');
                $('.status-item.s').attr('title','You have selected items.');
            } else {
                $('.status-item.s').removeClass('active');
                $('.status-item.s').attr('title','');
            }
        },1000);
        
        $('.cat').height('68px');
        $('.cat>h1').on('click',function(){
            $(this).parents('.cat').toggleClass('show');
            resize($(this).parents('.cat').attr('id'),$(this).parents('.cat').attr('category-type'));
        });
        
        $('.cat>.load-more:not(.click)').click(function(){
            var load_more = $(this);
            load_more.addClass('click');
            setTimeout(function(){load_more.removeClass('click');},5000);
            var ajax_send = ['gpanel.load_more',$(this).parents('.cat').find('.img-div').length-1,$('.ctx').attr('select-cat')];
            
            aj(ajax_send,'file/php/category.php/query.php?ajax=true',function(r){
            console.log(r);
            $(this).parents('.cat').find('.dump').append(r);
            /*
                r = JSON.parse(JSON.stringify(r));
                for (i = 0; i < r.length; i++) {
                    $(this).parents('.cat').find('.dump').append("");
                }*/
            });
        });
        
        /*Add Button*/
        $('.mnbtn>.button').on('click',function(e){
            $('.ctx>.dump').empty();
            $('.ctx').css({"left":$('.mnbtn').offset()['left']+"px","top":$('.mnbtn').offset()['top']+"px"});
            generate_context_menu_content('add.button');
            $('.ctx').addClass('ctx-show');
            //$(this).parent().find('.menu').addClass('show');
            e.stopPropagation();
        });
        $('.x').on('click',function(){
            $('.add-menu').removeClass('show');
            $('.add-menu>div').removeClass('show');
        });
        /*CONTEXT MENU*/
        var p = [0,0];
        $( document ).on( "mousemove", function( event ) {
          p = [event.pageX,event.pageY];
          if(p[0] > $(window).width()-250) {
              p[0] = $(window).width()-250;
          }
        if($('.ctx').hasClass('ctx-show')){} else {
            $('.ctx').css({"left":p[0]+"px","top":p[1]+"px"});
        }
        });
        
        $(document).contextmenu(function(e) {
                e.preventDefault();
        });
        $(document).on("contextmenu",'.ctx-click',function(e) {
            if($('.ctx').hasClass('ctx-show')) {
                 $('.ctx').removeClass('ctx-show');
            } else {
                items = [];
                if(!$('.selected')[0]) {
                    $(".ctx").attr('select-type','single');
                    $(".ctx").attr('select-cat',$(e.target).parents('.cat').attr('id'));
                    if(!$(e.target).hasClass('.item-div')) {
                        items[0] = $(e.target).attr('id');
                    } else {
                        items[0] = $(e.target).parents('.item-div').attr('id');
                    }
                } else {
                    $(".ctx").attr('select-type','multiple');
                    $(".ctx").attr('select-cat',$('.cat.focus-selection').attr('id'));
                    
                    items = $('.selected').map(function(){
                        return this.id;
                    }).get();
                }
                /*
                $('.ctx>.dump').empty();
                $(".ctx").attr('select-type','single');
                if($(e.target).parents('.item-div').hasClass('selected') || $(e.target).hasClass('selected')) {
                    $(".ctx").attr('select-type','multiple');
                    $(".ctx").attr('select-cat',$('.cat.focus-selection').attr('id'));
                    $(".ctx").attr('select-item','');
                    
                    $('.selected').each(function() {
                        selected_item[$(this).attr("id")] = $(this).attr("id");
                        console.log($(this).attr("id"));
                    });
                        console.log(selected_item);
                }
                if($(".ctx").attr('select-type')=='single') {
                    selected_item = [];
                    $(".ctx").attr('select-cat',$(e.target).parents('.cat').attr('id'));
                    selected_item[1] = $(e.target).parents('.cat').attr('category-table');
                    if($(e.target).hasClass('item-div')) {
                        $(".ctx").attr('select-item',$(e.target).attr('id'));
                        selected_item[0] = $(e.target).attr('id');
                    } else {
                        $(".ctx").attr('select-item',$(e.target).parents('.item-div').attr('id'));
                        selected_item[0] = $(e.target).parents('.item-div').attr('id');
                    }
                }*/
                
                selection = {/*type:$(".ctx").attr('select-type'),*/category_id:$(".ctx").attr('select-cat')/*,item:selected_item*/};
                
                generate_context_menu_content(selection.category_id);
                
                $('.ctx').css({"left":p[0]+"px","top":p[1]+"px"});
                $('.ctx').addClass('ctx-show');
            }
        });
        $(document).on('click',function(){
            $('.menu.show').removeClass('show');
            $('.ctx').removeClass('ctx-show');
        });
        $('.content').css('width',($(window).width()-275)+"px");
var nt = 0;
        /* SELECT item-div */
        $('.cat>.dump').on('click','.selecteable',function(){
            $('.focus-selection').not(this).removeClass('focus-selection');
            $(this).parents('.cat').addClass('focus-selection');
            $(this).toggleClass('selected');
            $('.cat').not('.focus-selection').find('.selected').removeClass('selected');
        });
        $('.ctx').on('click','.ctx-option',function(e){
            //context_function([$(this).attr('option-method'),selection.item],selection.category_id);
                
            var item_values = {};
            $(this).find('.context-return').each(function() {
                item_values[$(this).attr("name")] = $(this).val();
            });
            context_function([$(this).attr('option-method'),items,item_values],selection.category_id);
        });
    });
</script>
<style>  /*context-menu-content*/
    .ctx-upload-label {
        position: relative;
        cursor: pointer;
        overflow: hidden;
    }
    .context-upload-button {
        opacity: 0;
        z-index: 100;
        position: absolute;
        top:-37px;
        left:0;
        height: 100px;
        width:270px;
        cursor: pointer;
    }
</style>
    </body>
</html>