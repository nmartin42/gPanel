<?php
return [
        [
            'category_id' => 'example2',
            'category_name' => 'Example2',
            'category_type' => 'list',
            'category_query' => 'SELECT id,name FROM test1;',
            'category_table' => 'test'
        ],
        [
            'id' => 'example1',
            'name' => 'Example1',
            'type' => 'image-small',
            'query' => 'SELECT id,url FROM img_test ORDER BY d DESC LIMIT 25;',
            'table' => 'img_test',
            'extra' => [
                        'image_url' => [
                                        'prefix' => 'https://nathan-martin.net/uploads/',
                                        'url_value' => 'url',
                                        'suffix' => '?w=200'
                                        ],
                        'text_field' => [
                                        'display' => 'false',
                                        'text_value' => 'url'
                                        ]
                       ]
        ],
        [
            'id' => 'example3',
            'name' => 'Example3',
            'type' => 'image-large',
            'query' => 'SELECT id,url FROM img_test ORDER BY d DESC LIMIT 25;',
            'table' => 'img_test',
            'extra' => [
                        'image_url' => [
                                        'prefix' => 'https://nathan-martin.net/uploads/',
                                        'url_value' => 'url',
                                        'suffix' => '?w=200'
                                        ],
                        'text_field' => [
                                        'display' => 'true',
                                        'text_value' => 'url'
                                        ]
                       ]
        ]
];