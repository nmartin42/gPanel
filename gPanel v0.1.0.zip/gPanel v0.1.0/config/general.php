<?php
/* GENERAL INFORMATION */
$server_root = "/home/nathan-martin.net/gpanel";
$current_domain = "https://nathan-martin.net/gpanel";

/* DATABASE INFORMATION */
$database = array(
    "hostname"  => "localhost",
    "user"      => "admin",
    "password"  => "admin",
    "database"  => "databaset"
    );