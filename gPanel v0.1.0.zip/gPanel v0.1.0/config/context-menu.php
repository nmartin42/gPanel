<?php
/*
### This page is for configuring your context menus. ###

### The menu trigger (content.*.trigger) is used to link the menu item with the functions.php file

### The id of "-1" is used by the "Add Button"
*/

return [
        [
            'category_id' => 'add.button',
            'content' => [
                            '1' => [
                                            'label' => 'Add Photo',
                                            'trigger' => 'gpanel.upload',
                                            'extra' => [
                                                        'upload' => [
                                                                            'save_location' => '/home/example/uploads/',
                                                                            'amount' => 'multiple',
                                                                            'type' => ["png","jpg"],
                                                                            'max_size' => '30',
                                                                            'query' => "INSERT INTO img_test VALUES (
                                                    NULL,
                                                    '',
                                                    NOW(),
                                                    0,
                                                    NULL,
                                                    '???FINALIMAGE???'
                                                   );"
                                                                          ]
                                                       ],
                                            'return' => 'upload.return'
                                         ]
                         ]
        ],
        [
            'category_id' => 'example1',
            'content' => [
                            '1' => [
                                            'label' => 'Delete2',
                                            'trigger' => 'example.2.delete'
                                         ]
                         ]
        ],
        [
            'category_id' => 'example2',
            'content' => [
                            '1' => [
                                            'label' => 'Add Photo',
                                            'trigger' => 'gpanel.upload',
                                            'extra' => [
                                                        'upload' => [
                                                                            'save_location' => '/home/example/uploads/',
                                                                            'amount' => 'multiple',
                                                                            'type' => ["png","jpg"],
                                                                            'max_size' => '30',
                                                                            'query' => "INSERT INTO img_test VALUES (
                                                    NULL,
                                                    '',
                                                    NOW(),
                                                    0,
                                                    NULL,
                                                    '???FINALIMAGE???'
                                                   );"
                                                                          ]
                                                       ],
                                            'return' => 'upload.return'
                                         ],
                            '2' => [
                                            'label' => 'Delete Photo',
                                            'trigger' => 'gpanel.delete_file',
                                            'extra' => [
                                                        'delete_file' => [
                                                                            'file_location' => '/home/example/uploads/',
                                                                            'database_table' => 'img_test',
                                                                            'file_value' => 'url'
                                                                          ]
                                                       ],
                                            'return' => 'upload.return'
                                         ]
                         ]
        ],
        [
            'category_id' => 'example3',
            'content' => [
                            '1' => [
                                            'label' => 'Add Photo',
                                            'trigger' => 'gpanel.upload',
                                            'extra' => [
                                                        'upload' => [
                                                                            'save_location' => '/home/example/uploads/',
                                                                            'amount' => 'single',
                                                                            'type' => ["png","jpg"],
                                                                            'max_size' => '30',
                                                                            'query' => "INSERT INTO img_test VALUES (
                                                    NULL,
                                                    '',
                                                    NOW(),
                                                    0,
                                                    NULL,
                                                    '???FINALIMAGE???'
                                                   );"
                                                                          ]
                                                       ],
                                            'return' => 'upload.return'
                                         ],
                            '2' => [
                                            'label' => 'Delete Photo',
                                            'trigger' => 'gpanel.delete_file',
                                            'extra' => [
                                                        'delete_file' => [
                                                                            'file_location' => '/home/example/uploads/',
                                                                            'database_table' => 'img_test',
                                                                            'file_value' => 'url'
                                                                          ]
                                                       ],
                                            'return' => 'upload.return'
                                         ]
                         ]
        ]
];